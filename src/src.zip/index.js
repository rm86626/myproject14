import ReactDOM from 'react-dom'
import React from 'react'
import App from './App'

// ReactDOM React中用来操作DOM对象
ReactDOM.render(
    <App/>,
    document.getElementById("app")
)