export default {
    link:'<a href="http://www.baidu.com">百度</a>'
}